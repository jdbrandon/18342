/*
 * rot13.c: ROT13 cipher test application
 *
 * Authors: Jeff Brandon jdbrando@andrew.cmu.edu
 * Date:    Wed Oct 1 21:17:06 UTC 2014
 */

#include <bits/fileno.h>
#include <bits/types.h>
#include <stdlib.h>
#include <unistd.h>

/* Main
	Reads from stdin, performing rot13 on all data read.
	Writes result of rot13 to stdout.
	If no bytes are read the program exits with status 0.
	If an error occurs during a read or write call the program 
	exits with status 1.
	exit never returns but in order to compile successfully
	I added (rather kept) the return -255; statement at the end of main.
*/
int main(void) {
	void rot13(char*, size_t);
	char buf[512];
	ssize_t res;
	while((res = read(STDIN_FILENO, buf, 512)) > 0){
		if(buf[0] == '\n')
			exit(0); /* no input -> exit successfully */
		rot13(buf, (size_t) res);
		res = write(STDOUT_FILENO, buf, res);
		if(res < 0)
			exit(1); /* write failed -> exit with error status */
	}
	if(res)
		exit(1); /* read failed -> exit with error status */
	exit(0); /* exit successfully */
	return -255;
}

/* Given a buffer and its length, performs a rotation
   of 13 on all letters in the buffer.
	buf - the buffer
	size - the length of the buffer in bytes
	returns: void, buf contains rotated version of
		its former value on completion.
*/
void rot13(char* buf, size_t size){
	int i;
	char c;
	for(i=0; i<size; i++){
		c = *(buf+i);	/* store character in local variable to reduce memory access */
		if((c >= 'A' && c < ('A' + 13)) || 
		   (c >= 'a' && c < ('a' + 13)))
			c += 13; /* rotate up */
		else if((c >= ('A' + 13) && c <= 'Z') ||
			(c >= ('a' + 13) && c <= 'z'))
			c -= 13; /* rotate down */
		*(buf+i) = c;	/* write c back to buffer */
	}
}
