/*
 * errno.c: Defines the global errno variable
 *
 * Author: Mike Kasick <mkasick@andrew.cmu.edu>
 * Date:   Sun, 07 Oct 2007 01:31:00 -0400
 */

int errno = 0;
