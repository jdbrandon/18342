cp kernel.bin /media/card;
umount /media/card;
mount /media/card;
